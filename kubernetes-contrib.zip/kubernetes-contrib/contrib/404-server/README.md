The 404-server (defaultbackend) has moved to the
[kubernetes/ingress](https://github.com/kubernetes/ingress) repository.
