The serve_hostname has moved to https://github.com/kubernetes/kubernetes/tree/master/test/images/serve-hostname
