The test-webserver has moved to https://github.com/kubernetes/kubernetes/tree/master/test/images/test-webserver
