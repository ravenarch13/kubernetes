The Ingress controllers have moved to the
[kubernetes/ingress](https://github.com/kubernetes/ingress) repository.
