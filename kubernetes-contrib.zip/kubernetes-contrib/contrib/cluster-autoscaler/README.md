Cluster Autoscaler has moved to: https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler
