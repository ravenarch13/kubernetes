Translation of the systemd configuration files into upstart scripts
in order to support Ubuntu 14.04.