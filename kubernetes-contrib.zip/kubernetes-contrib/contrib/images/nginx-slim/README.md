The `nginx-slim` image has moved to the
[kubernetes/ingress](https://github.com/kubernetes/ingress/tree/master/images/nginx-slim)
repository.
