The `ubuntu-slim` image has moved to the
[kubernetes/ingress](https://github.com/kubernetes/ingress/tree/master/images/ubuntu-slim)
repository.
