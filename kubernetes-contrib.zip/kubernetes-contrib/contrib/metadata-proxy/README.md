This project has moved to
https://github.com/GoogleCloudPlatform/k8s-metadata-proxy
