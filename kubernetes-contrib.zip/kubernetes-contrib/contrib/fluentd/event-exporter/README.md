This project has been moved to
https://github.com/GoogleCloudPlatform/k8s-stackdriver/tree/master/event-exporter
