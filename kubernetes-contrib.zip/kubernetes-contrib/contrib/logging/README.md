# Collecting logs with sidecar container

Information was moved to the [official documentation](https://kubernetes.io/docs/user-guide/logging/overview/).

