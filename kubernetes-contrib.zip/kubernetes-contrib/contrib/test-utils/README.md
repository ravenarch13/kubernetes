# GCS test buckets utilities

Various utilities for getting test data from public GCS buckets