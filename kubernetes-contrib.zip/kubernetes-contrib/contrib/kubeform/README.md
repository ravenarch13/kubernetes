# kubeform

kubeform is a Terraform provider plugin for Kubernetes

# License

This project is licensed under the Apache 2.0 license. See the LICENSE file.
