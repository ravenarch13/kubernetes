# This sub-project has moved to its own repository.

Please see [the new home](https://github.com/kubernetes/git-sync), or use `go get k8s.io/git-sync`.

[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/contrib/git-sync/README.md?pixel)]()
