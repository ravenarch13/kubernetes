# docker-git2consul

Custom docker image for [git2consul](https://github.com/Cimpress-MCP/git2consul)

## Up and running

```bash
# This file is already packed in the docker image with appropriate repo name 
# This is just for INFO
# Branch is replaced with env variable branch 
# Max socket is set to one
$ mkdir -p /tmp/git2consul.d
$ cat <<EOF > /tmp/git2consul.d/config.json
{
  "version": "1.0",
  "repos" : [{
    "name" : "sample_configuration",
    "url" : "https://github.com/ryanbreen/git2consul_data.git",
    "branches" : ["BRANCH"],
    "hooks": [{
      "type" : "polling",
      "interval" : "1"
    }]
  }]
}
EOF

$ docker run -d -p 8400:8400 -p 8500:8500 -p 8600:53/udp -h node1 --name consul progrium/consul -server -bootstrap
$ CONSUL_IP=$(docker inspect --format '{{ .NetworkSettings.IPAddress }}' consul)
$ docker run -d --name git2consul -v /tmp/git2consul.d:/etc/git2consul.d -e "branch=[dev|qa|stage|master] -e "CONSUL_IP=$CONSUL_IP" {ecs-git2consul}
```
