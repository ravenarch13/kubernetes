#### GLP K8S templates

- Repo contains templates that we use with Jenkins to deploy our services
