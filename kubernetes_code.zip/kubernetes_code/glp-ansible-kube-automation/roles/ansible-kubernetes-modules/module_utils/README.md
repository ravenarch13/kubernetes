The `k8_common.py` and `openshift_common.py` modules are not currently available in an official release of Ansible. They are part of Ansible, as you'll find them in the `devel` branch. At some point they will make it into an official release. Until then, they're included here for convenience.

If you have uncovered a problem, or would like to make a change, please open an issue and submit pull requess at the [Ansible repo](https://github.com/ansible/ansible).
