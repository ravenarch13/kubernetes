#### Git2consul

- create secret with consul token
- create config map

```
$ kubectl create secret generic consul-token --from-literal="consul-token=14e27b41-9725-321b-6d75-2fz7057e56aa"

```

```
$ kubectl create configmap git2consul --from-file=configs/config.json

```
