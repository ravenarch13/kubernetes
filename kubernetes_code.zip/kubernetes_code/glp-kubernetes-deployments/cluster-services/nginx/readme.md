### Nginx ingress controller via helm

- Create RBAC using yaml
- Deploy using

#### Ingress service did not take service annotation
#### Edited service to add annotations

```
metadata:
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-connection-idle-timeout: "6000"
    service.beta.kubernetes.io/aws-load-balancer-proxy-protocol: '*'
    service.beta.kubernetes.io/aws-load-balancer-ssl-cert: ""
```

- Also disabled port 80 access until we implement redirection

###### Above did not work

- Deployed ingress controller using https://github.com/kubernetes/ingress-nginx/blob/master/deploy/README.md
