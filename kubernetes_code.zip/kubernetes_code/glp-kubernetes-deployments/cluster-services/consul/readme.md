# Consul statefulset

  - No persistent storage required
  - ACL bootstrapping for integration with git2consul
  - Power of statefulset

# Steps to deploy!

  - Update configs/server.json to update acl tokens/encryption keys
  - Create secret from the config file
 ```shell
 $ kubectl create secret generic consul --from-file=configs/server.json
 ```
  - Service has to exist before SF is deployed
```shell
$ kubectl apply -f consul-statefulset.yaml
```
  - Lastly create an ingress when satisfied
``` shell
$ kubectl apply -f consul-ingress.yaml
```
