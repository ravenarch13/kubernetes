### External DNS

- https://github.com/zparnold/external-dns/blob/fb68267a6bb2d5f8af0d24da195c6abd630f84a8/docs/tutorials/aws.md

- Modified role for workers to allow route53 privileges

- Updated default sa to have permissions to view service/ingress at cluster level
