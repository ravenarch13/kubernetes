####

./bin/kafka-console-producer.sh --topic=GLP-Topic-LCD-Service_Topic --broker-list=kafka-uat-kafka-headless:9092

####

./bin/kafka-console-consumer.sh --topic=AutoBahnISCTopicPro-LCD-Service_Topic --bootstrap-server=kafka-uat-kafka-headless:9092

./bin/kafka-console-consumer.sh --topic=GLP-Topic-LCD-Service_Topic --bootstrap-server=kafka-uat-kafka-headless:9092

####

 ./bin/kafka-topics.sh --describe --zookeeper kafka-uat-zookeeper:2181 --topic GLP-Topic-LCD-Service_Topic

####

./bin/kafka-topics.sh --describe --zookeeper kafka-uat-zookeeper:2181 --topic topic


####


./bin/kafka-topics.sh --list --zookeeper kafka-uat-zookeeper:2181



###

./bin/kafka-topics.sh --zookeeper kafka-uat-zookeeper:2181 --delete --topic GLP-Topic-LCD-Service_Topic


###

./bin/kafka-topics.sh --zookeeper kafka-uat-zookeeper:2181 --alter --topic GLP-Topic-LCD-Service_Topic --config retention.ms=1000
