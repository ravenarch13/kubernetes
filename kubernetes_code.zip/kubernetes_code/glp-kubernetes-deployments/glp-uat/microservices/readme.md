#### Note: Services are deployed via Jenkins-kubernetes continuous plugin. Just samples here
