#### Kong Setup

- Create secret for kong password
- Create secret for kong ui
- RDS is created for kong


```
$ kc create secret generic kong-db-passwd --from-literal="kong-db-passwd=********" -n glp-uat
$ kc create secret generic kong-ui-passwd --from-literal="ui-passwd=******" -n glp-uat

```
