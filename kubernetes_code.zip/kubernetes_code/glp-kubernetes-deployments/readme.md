#### GLP Deployment on Kubernetes

- This repo contains yaml files, scripts, readme docs for deploying glp on vanilla kube installation
