# NGINX Plus Ingress Controller

The Ingress controller implementation for NGINX Plus has been merged with the implementation for NGINX. You can read instructions on how to build the Ingress controller image for NGINX Plus [here](../nginx-controller).
